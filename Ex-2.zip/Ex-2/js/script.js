$(document).ready(function () {
    $(".slider").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: true,
        dots: true,
        prevArrow:
        "<span class ='slick-prevarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",
    nextArrow:
        "<span class='slick-nextarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    arrows: false,
                },
            },
        ],
    });
});
$(document).ready(function () {
    $(".first-row").slick({
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 4,
        arrows: true,
        autoplay: false,
        dots: false,
       
        prevArrow:
        "<span class ='slick-prevarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",
    nextArrow:
        "<span class='slick-nextarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",

        responsive: [
            {
                breakpoint: 999999,
                settings: "unslick",
            },
            {
                breakpoint: 1199,
                settings: {
                    infinite: true,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: true,
                    autoplay: true,
                },
            },
            {
                breakpoint: 1024,
                settings: {
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    arrows: true,
                    autoplay: false,
                },
            },
            {
                breakpoint: 737,
                settings: {
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: true,
                    autoplay: false,
                },
            },
            {
                breakpoint: 567,
                settings:{
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }
        ],
    });
});

$(document).ready(function () {
    $(".featured-brands-content").slick({
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 4,
        arrows: true,
        autoplay: false,
        dots: false,
       
        prevArrow:
        "<span class ='slick-prevarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",
    nextArrow:
        "<span class='slick-nextarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",

        responsive: [
            {
                breakpoint: 999999,
                settings: "unslick",
            },
            {
                breakpoint: 1024,
                settings: {
                    infinite: true,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    arrows: true,
                    autoplay: true,
                },
            },
            {
                breakpoint: 768,
                settings:{
                    slidesToShow: 3,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 666,
                settings:{
                    slidesToShow: 2,
                    slidesToScroll: 1,
                }
            }
        ],
    });
});


$(document).ready(function () {
    $(".shop-product-slider").slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        infinite: true,
      
        autoplaySpeed: 2000,
        arrows: true,
        prevArrow:
        "<span class ='slick-prevarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",
    nextArrow:
        "<span class='slick-nextarrow d-flex align-item-center justify-content-center position-relative'><svg class='icon'> <use xlink:href='image/allsvg.svg#left-arrow'></use></svg>",
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    arrows: true,
                    slidesToShow: 3,
                },
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: true,
                    slidesToShow: 2,
                },
            },
            {
                breakpoint: 567,
                settings:{
                    slidesToShow: 2,
                    slidesToScroll: 1,
                }
            },
            {
                breakpoint: 480,
                settings:{
                    slidesToShow: 1,
                    slidesToScroll: 1,
                }
            }
        ],
    });
});

/*----- search-bar-toggle -----*/
$(document).ready(function(){
    $(".main-icon").click(function(){
        $(".search-toggle").show();
    });
});

$(document).ready(function(){
    $(".main-icon").click(function(){
        $(".main-icon").hide();
    });
});

$(document).ready(function(){
    $(".main-icon").click(function(){
        $(".close-icon").show();
    });
});

$(document).ready(function(){
    $(".close-icon").click(function(){
        $(".search-toggle").hide();
    });
});
$(document).ready(function(){
    $(".close-icon").click(function(){
        $(".close-icon").hide();
        $(".main-icon").show();
    });
});

/*----- hamburger ----*/
const hamburger = document.querySelector(".hamburger-menu");
const navMenu = document.querySelector(".navbar-menu");

hamburger.addEventListener("click", mobileMenu);

function mobileMenu() {
    hamburger.classList.toggle("active");
    navMenu.classList.toggle("active");
}

/*--- footer-dropdown ---*/
$(document).ready(function () {
    $('footer .dropdown-bottom ').click(function () {
        $(this).toggleClass('open');

    });
});

/*----- open-close-hamburger-menu -----*/
$(document).ready(function(){
    $(".open-hamburger").click(function(){
        $(".open-hamburger").hide();
        $(".close-hamburger").show();
    });
});
$(document).ready(function(){
    $(".close-hamburger").click(function(){
        $(".open-hamburger").show();
        $(".close-hamburger").hide();
      
    });
});

/*---- Responsive-tabs  ----*/
$('#responsiveTabsDemo').responsiveTabs({
    startCollapsed: 'accordion'
});
$('.r-tabs-tab, .r-tabs-anchor').on('click', function () {
    $(this).parents(".shop-accordion-main").find('.r-tabs-state-active .shop-product-slider').each(function () {
        $(this).slick('refresh');

    });
});
$(window).on('load', function () {
    $('.shop-products-slider').slice('refresh');
});
$(document).ready(() => {
    // Make featured products tab open in mobile
    const featuredProdsTab = $('#responsiveTabsDemo .r-tabs-accordion-title .r-tabs-anchor');
    window.innerWidth < 1023 && featuredProdsTab.length > 0 && featuredProdsTab.first()[0].click();
});
$('.shop-accordion-main').find('.r-tabs-anchor').each(function () {
    $(this).addClass('button');
}); 
